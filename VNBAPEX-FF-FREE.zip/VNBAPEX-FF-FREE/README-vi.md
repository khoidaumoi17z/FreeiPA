# VNBAPEX FF FREE — bản 6

App hiển thị website VNBAPEX trong WKWebView. Nhấn tải hồ sơ .mobileconfig sẽ mở liên kết bằng trình duyệt hệ thống (thường là Safari; tùy trình duyệt mặc định của thiết bị). Không còn hộp thoại Lưu vào Tệp/Chia sẻ và bộ tải tệp native.

Sau khi Safari hiện yêu cầu tải hồ sơ, nhấn Cho phép. Sau đó vào Cài đặt → Hồ sơ đã tải về → Cài đặt và xác nhận. Cho phép tải không tự kích hoạt hồ sơ. Tên miền của liên kết có thể hiện trong trình duyệt.

## Giao diện

Đã bỏ Không cần IPA và cả ba ô Truy vấn được mã hóa / Lọc miền theo lựa chọn / Bạn giữ quyền kiểm soát. App cũng tự sửa hai mục này khi website còn bản cũ. Giữ tên app, biểu tượng khiên, âm nhạc và credit. Source web đi kèm đã xóa trực tiếp ba ô này.

## Cập nhật trên GitHub

1. Trong kho FreeiPA, thay ZIP gốc bằng VNBAPEX-FF-FREE.zip mới, giữ đúng tên rồi Commit vào main. Nếu có thư mục source đã giải nén, cần cập nhật hoặc xóa bản cũ vì workflow ưu tiên thư mục này.
2. Giữ .github/workflows/vnbapex-ff-free.yml đang dùng. Actions → Build VNBAPEX FF FREE IPA → Run workflow → main.
3. Đợi Success, tải artifact VNBAPEX-FF-FREE-IPA, giải nén lấy IPA unsigned rồi ký lại và cài app. Build number 6, bundle ID com.vnbapex.fffree, iPhone/iPad iOS 15 trở lên.
4. Trong kho vnbapex-shield, thay VNBAPEX-DNS-Web.zip bằng bản web mới và Commit. Giữ workflow Pages đang dùng. Khi Pages triển khai xong, tải lại trang để giao diện web cũng đổi.

## Source

Giữ cách làm rối URL bằng mảng byte và tên nội bộ ngắn, cùng cấu hình tối ưu/strip Release. Đây không phải mã hóa bảo mật: URL và cấu hình DNS vẫn có thể tìm thấy. Đừng công khai repo nếu muốn giới hạn người xem source.

Đã kiểm tra cấu trúc nguồn, plist, workflow và ZIP. Chưa biên dịch Xcode hoặc kiểm thử trên iPhone trong môi trường Linux hiện tại. Không đảm bảo mọi thiết bị; cài IPA còn phụ thuộc chữ ký hợp lệ. App tải hồ sơ DNS, không có chức năng patch game hoặc chống khóa tài khoản.

Bản 6 xóa đoạn mô tả dưới tiêu đề và đoạn giới thiệu ở footer theo hình đánh dấu; đổi nhãn tải thành Tải VNBAPEX. App áp dụng chỉnh sửa cả với trang web cũ.
