# VNBAPEX FF FREE — tải hồ sơ trong app

App giữ nguyên giao diện website VNBAPEX trong WKWebView. Địa chỉ trang được biểu diễn bằng mảng byte trong App/Route.swift và khôi phục lúc chạy.

Khi nhấn tải hồ sơ .mobileconfig, app dùng URLSession tải trực tiếp, hiển thị trạng thái tải và nút Hủy. Sau đó chọn Lưu vào Tệp hoặc Chia sẻ. Luồng tải này không gọi Safari, kể cả khi liên kết mở tab mới. App chỉ nhận hồ sơ HTTPS cùng máy chủ với website, giới hạn 2 MiB và kiểm tra nội dung là hồ sơ DNS; lỗi tải không tự chuyển sang trình duyệt. Liên kết ngoài khác do người dùng nhấn vẫn có thể mở ứng dụng ngoài.

URL không lưu dưới dạng chuỗi rõ trong Info.plist. Mảng byte XOR chỉ là làm rối, không phải mã hóa bảo mật; vẫn có thể phục hồi URL bằng phân tích mã hoặc quan sát mạng.

## Cập nhật repo FreeiPA đang có

1. Trong kho khoidaumoi17z/FreeiPA, thay VNBAPEX-FF-FREE.zip ở thư mục gốc bằng ZIP mới, giữ nguyên tên, rồi Commit changes vào main. Không giải nén ZIP trên GitHub.
2. Giữ workflow .github/workflows/vnbapex-ff-free.yml đang có. Tên đuôi phải là .yml, không phải .ym. Nếu repo có thư mục VNBAPEX-FF-FREE đã giải nén thì cập nhật thư mục đó hoặc bỏ bản cũ: workflow ưu tiên thư mục đã có hơn ZIP.
3. Actions → Build VNBAPEX FF FREE IPA → Run workflow → main. Đợi Success.
4. Mở lần chạy → Summary → Artifacts → VNBAPEX-FF-FREE-IPA, tải và giải nén để lấy VNBAPEX-FF-FREE-unsigned.ipa.
5. Ký lại IPA bằng chứng chỉ/provisioning profile hợp lệ cho thiết bị rồi cài bản mới. Build number là 3; bundle ID vẫn com.vnbapex.fffree. App không cần quyền Network Extension/App Groups.

Nếu tạo repo mới, tải ZIP vào gốc và sao chép Workflow/vnbapex-ff-free.yml thành .github/workflows/vnbapex-ff-free.yml bên ngoài ZIP. Chỉ tải ZIP sẽ không đăng ký workflow.

## Tải tệp khác với cài hồ sơ

Lưu vào Tệp/Chia sẻ chỉ xuất tệp. App không có API để tự cài hoặc kích hoạt hồ sơ. iOS yêu cầu người dùng xác nhận trong Cài đặt. Không đảm bảo tệp xuất qua Files sẽ tự xuất hiện ở mục Hồ sơ đã tải về; luồng cài có thể cần cách phân phối hồ sơ được iOS hỗ trợ, chẳng hạn tệp đính kèm email. Không có chuyển Safari tự động trong app này.

Mô tả hồ sơ được website cung cấp. Việc đổi mô tả không đổi loại payload DNS và không thêm tính năng patch game/chống khóa tài khoản. Nội dung trang được cập nhật từ GitHub Pages; thay đổi mã tải native cần build và ký lại IPA.

Target iPhone/iPad iOS/iPadOS 15 trở lên. Môi trường giao source là Linux, không có Xcode: đã kiểm tra cấu trúc nguồn, plist, icon, workflow và ZIP; chưa biên dịch Xcode hoặc kiểm thử trên thiết bị. Cài đặt còn phụ thuộc chữ ký và thiết bị, không bảo đảm chạy trên mọi máy.

## Bản làm rối source

Các tên tự định nghĩa ở mã native đã được đổi thành tên ngắn. Release bật tối ưu toàn mô-đun và loại bỏ ký hiệu debug/Swift qua các thiết lập Xcode. Các hàm UIKit/WebKit, tên thương hiệu, thông báo giao diện và thông tin bắt buộc để iOS chạy app được giữ nguyên. Không hứa loại bỏ tất cả thông tin runtime.

Không đăng source vào repo công khai nếu muốn giới hạn người đọc: đổi repo sang Private trước khi cập nhật. Mã và URL vẫn có thể bị khôi phục từ IPA, và website GitHub Pages đang công khai vẫn truy cập được. Làm rối không thay thế đăng nhập hoặc kiểm soát quyền tải. Các thiết lập strip cần được kiểm chứng bằng lần build GitHub và thử app thực tế.
