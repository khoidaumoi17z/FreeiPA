# VNBAPEX FF FREE — app iOS mở website

App dùng WKWebView để mở nguyên https://khoidaumoi17z.github.io/vnbapex-shield/. Không thay HTML/CSS/JS của website. Tên app và biểu tượng khiên là VNBAPEX FF FREE. Nội dung bên trong giữ thương hiệu web theo yêu cầu không đổi thiết kế. Cập nhật GitHub Pages thì app đọc nội dung mới, không cần build IPA lại để đổi nội dung web.

Nhấn tải .mobileconfig sẽ mở Safari. Cài hồ sơ trong Cài đặt; app không tự cài hồ sơ, không bật VPN hoặc patch game. Cần kết nối Internet và website Pages hoạt động. Cấu hình WebKit cho phép thử tự phát âm thanh, không đảm bảo phát nền khi khóa máy hoặc chuyển app.

## Build bằng GitHub trên điện thoại
1. Tạo repo Public mới vnbapex-ff-free, bật Add a README, nhánh main.
2. Code → Add file → Upload files → tải VNBAPEX-FF-FREE.zip vào gốc repo, giữ đúng tên và không giải nén → Commit changes.
3. Add file → Create new file, nhập .github/workflows/vnbapex-ff-free.yml. Dán toàn bộ nội dung workflow đi kèm rồi Commit changes vào main.
4. Actions → Build VNBAPEX FF FREE IPA → Run workflow → main. Không cần bật GitHub Pages cho repo build app này.
5. Khi Success, mở lần chạy → Summary → Artifacts → VNBAPEX-FF-FREE-IPA. Tải ZIP artifact, giải nén trong ứng dụng Tệp để lấy VNBAPEX-FF-FREE-unsigned.ipa.
6. Ký IPA bằng chứng chỉ/provisioning profile hợp lệ cho thiết bị và bundle ID. App không cần App Groups hay Network Extension như bản VPN cũ.

## Giới hạn
Đây là mã nguồn và workflow tạo IPA unsigned, chưa có bản IPA được biên dịch tại thời điểm giao gói. Môi trường hiện tại là Linux, không có Xcode. Chưa chạy CI hoặc kiểm thử cài trên thiết bị. Target iPhone/iPad chạy iOS/iPadOS 15 trở lên; khả năng cài còn phụ thuộc chữ ký, profile, thiết bị và chính sách iOS. Không thể bảo đảm mọi thiết bị. Đây không phải ứng dụng dành cho Android, Apple Watch hoặc Apple TV.

Để đổi website, sửa WebsiteURL trong App/Info.plist rồi build lại. Không có chứng chỉ hay thông tin tài khoản trong mã nguồn.

## Đồng bộ giao diện FF FREE
Gói web mới đã xóa KHÔNG CẦN IPA và đổi mô tả chính/hồ sơ thành Antiban Auto Patch Online. Vì app mở website qua WKWebView, cần cập nhật VNBAPEX-DNS-Web.zip trong repo vnbapex-shield để các thay đổi xuất hiện. Không cần build lại IPA cho thay đổi nội dung web. Tên app giữ VNBAPEX FF FREE. Nhãn này không thêm khả năng patch game hoặc chống khóa tài khoản.
