from pathlib import Path
import plistlib,sys
app=Path(sys.argv[1]);info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleDisplayName']=='VNBAPEX FF FREE'
assert info['WebsiteURL'].startswith('https://')
assert info['UIDeviceFamily']==[1,2]
magic=(app/info['CFBundleExecutable']).read_bytes()[:4]
assert magic in (b'\xcf\xfa\xed\xfe',b'\xca\xfe\xba\xbe',b'\xca\xfe\xba\xbf'), 'Not a device Mach-O executable'
assert not (app/'PlugIns').exists(), 'This app requires no VPN extension'
print('Verified app name, website URL, device families and executable.')
