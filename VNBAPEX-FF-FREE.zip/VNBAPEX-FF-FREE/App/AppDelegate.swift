import UIKit
import WebKit
import AVFoundation

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = WebsiteController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}

final class WebsiteController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var websiteURL: URL!
    private var showingError = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 7/255, green: 16/255, blue: 14/255, alpha: 1)
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "WebsiteURL") as? String,
              let url = URL(string: raw), url.scheme == "https", url.host != nil else {
            showError("Địa chỉ website trong app không hợp lệ.")
            return
        }
        websiteURL = url
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.allowsBackForwardNavigationGestures = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        webView.load(URLRequest(url: url, cachePolicy: .reloadRevalidatingCacheData))
    }

    private func openExternal(_ url: URL) {
        guard url.scheme == "https" || url.scheme == "http" else { return }
        UIApplication.shared.open(url, options: [:]) { [weak self] success in
            if !success { self?.showError("Không mở được liên kết. Hãy thử bằng Safari.") }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.pathExtension.lowercased() == "mobileconfig" {
            decisionHandler(.cancel)
            openExternal(url)
            return
        }
        if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
            return
        }
        guard url.scheme == "https" else {
            decisionHandler(.cancel)
            return
        }
        if url.host != websiteURL.host || navigationAction.targetFrame == nil {
            decisionHandler(.cancel)
            openExternal(url)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { openExternal(url) }
        return nil
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled {
            showError("Không tải được website. Kiểm tra kết nối mạng hoặc website GitHub Pages.")
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { showError("Tải trang bị gián đoạn. Vui lòng thử lại.") }
    }

    private func showError(_ message: String) {
        guard !showingError else { return }
        showingError = true
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let alert = UIAlertController(title: "VNBAPEX FF FREE", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Thử lại", style: .default) { [weak self] _ in
                self?.showingError = false
                if let url = self?.websiteURL { self?.webView?.load(URLRequest(url: url)) }
            })
            alert.addAction(UIAlertAction(title: "Đóng", style: .cancel) { [weak self] _ in self?.showingError = false })
            self.present(alert, animated: true)
        }
    }
}
