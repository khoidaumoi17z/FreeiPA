import UIKit
import WebKit
import AVFoundation

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = x0()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}

final class x0: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var x2: URL!
    private var x5 = false
    private var x3: x1?
    private var x4: UIView?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 7/255, green: 16/255, blue: 14/255, alpha: 1)
        guard let raw = X9.v0(),
              let url = URL(string: raw), url.scheme == "https", url.host != nil else {
            x10("Địa chỉ website trong app không hợp lệ.")
            return
        }
        x2 = url
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.allowsBackForwardNavigationGestures = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        webView.load(URLRequest(url: url, cachePolicy: .reloadRevalidatingCacheData))
    }

    private func x6(_ url: URL) {
        guard url.scheme == "https" || url.scheme == "http" else { return }
        UIApplication.shared.open(url, options: [:]) { [weak self] success in
            if !success { self?.x10("Không mở được liên kết. Hãy thử bằng Safari.") }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.pathExtension.lowercased() == "mobileconfig" {
            decisionHandler(.cancel)
            x7(url)
            return
        }
        if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
            return
        }
        guard url.scheme == "https" else {
            decisionHandler(.cancel)
            return
        }
        if navigationAction.targetFrame == nil && url.host == x2.host {
            decisionHandler(.cancel)
            webView.load(navigationAction.request)
        } else if url.host != x2.host {
            decisionHandler(.cancel)
            x6(url)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            if url.pathExtension.lowercased() == "mobileconfig" {
                x7(url)
            } else if url.scheme == "https", url.host == x2.host {
                webView.load(navigationAction.request)
            } else {
                x6(url)
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled {
            x10("Không tải được website. Kiểm tra kết nối mạng hoặc website GitHub Pages.")
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { x10("Tải trang bị gián đoạn. Vui lòng thử lại.") }
    }

    private func x7(_ url: URL) {
        guard x3 == nil, presentedViewController == nil else { return }
        guard url.scheme == "https", url.host == x2.host else {
            x10("Địa chỉ tải hồ sơ không hợp lệ.")
            return
        }
        let overlay = UIView(frame: view.bounds)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.85)
        let spinner = UIActivityIndicatorView(style: .large)
        spinner.color = .systemMint
        spinner.startAnimating()
        let label = UILabel()
        label.text = "Đang tải hồ sơ VNBAPEX…"
        label.textColor = .white
        label.textAlignment = .center
        let cancel = UIButton(type: .system)
        cancel.setTitle("Hủy tải", for: .normal)
        cancel.addTarget(self, action: #selector(x8), for: .touchUpInside)
        let stack = UIStackView(arrangedSubviews: [spinner, label, cancel])
        stack.axis = .vertical
        stack.spacing = 24
        stack.translatesAutoresizingMaskIntoConstraints = false
        overlay.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualTo: overlay.widthAnchor, multiplier: 0.9)
        ])
        view.addSubview(overlay)
        x4 = overlay
        let download = x1(url: url) { [weak self] result in
            guard let self = self else { return }
            self.x3 = nil
            self.x4?.removeFromSuperview()
            self.x4 = nil
            switch result {
            case .success(let file): self.x9(file)
            case .failure(let error):
                if (error as NSError).code != NSURLErrorCancelled {
                    self.x10("Không tải được hồ sơ hợp lệ. Kiểm tra kết nối và thử lại.")
                }
            }
        }
        x3 = download
        download.start()
    }

    @objc private func x8() {
        x3?.cancel()
    }

    private func x9(_ file: URL) {
        let alert = UIAlertController(title: "Hồ sơ đã tải xong",
            message: "Chọn lưu vào Tệp hoặc chia sẻ. App không tự cài hay kích hoạt hồ sơ; việc cài đặt cần xác nhận trong Cài đặt của iOS.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Lưu vào Tệp", style: .default) { [weak self, weak alert] _ in
            alert?.dismiss(animated: true) {
                self?.present(UIDocumentPickerViewController(forExporting: [file], asCopy: true), animated: true)
            }
        })
        alert.addAction(UIAlertAction(title: "Chia sẻ", style: .default) { [weak self, weak alert] _ in
            alert?.dismiss(animated: true) {
                guard let self = self else { return }
                let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                share.popoverPresentationController?.sourceView = self.view
                share.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 1, height: 1)
                self.present(share, animated: true)
            }
        })
        alert.addAction(UIAlertAction(title: "Đóng", style: .cancel))
        present(alert, animated: true)
    }

    private func x10(_ message: String) {
        guard !x5 else { return }
        x5 = true
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let alert = UIAlertController(title: "VNBAPEX FF FREE", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Thử lại", style: .default) { [weak self] _ in
                self?.x5 = false
                if let url = self?.x2 { self?.webView?.load(URLRequest(url: url)) }
            })
            alert.addAction(UIAlertAction(title: "Đóng", style: .cancel) { [weak self] _ in self?.x5 = false })
            self.present(alert, animated: true)
        }
    }
}

private final class x1: NSObject, URLSessionDataDelegate {
    private let url: URL
    private let completion: (Result<URL, Error>) -> Void
    private let x11 = 2 * 1024 * 1024
    private var data = Data()
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var x13 = false

    init(url: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        self.url = url
        self.completion = completion
    }

    func start() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 60
        configuration.urlCache = nil
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        self.session = session
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/x-apple-aspen-config, application/xml", forHTTPHeaderField: "Accept")
        task = session.dataTask(with: request)
        task?.resume()
    }

    func cancel() { task?.cancel() }

    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard request.url?.scheme == "https", request.url?.host == url.host else {
            completionHandler(nil)
            return
        }
        completionHandler(request)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let response = response as? HTTPURLResponse, response.statusCode == 200,
              response.url?.scheme == "https", response.url?.host == url.host,
              response.expectedContentLength <= Int64(x11) else {
            completionHandler(.cancel)
            finish(.failure(x12()))
            return
        }
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard self.data.count + data.count <= x11 else {
            dataTask.cancel()
            finish(.failure(x12()))
            return
        }
        self.data.append(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error { finish(.failure(error)); return }
        do {
            guard let profile = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
                  profile["PayloadType"] as? String == "Configuration",
                  let payloads = profile["PayloadContent"] as? [[String: Any]], !payloads.isEmpty,
                  payloads.allSatisfy({ $0["PayloadType"] as? String == "com.apple.dnsSettings.managed" }) else {
                throw x12()
            }
            let folder = try FileManager.default.url(for: .cachesDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                .appendingPathComponent("Profiles", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let file = folder.appendingPathComponent("VNBAPEX-1.0.mobileconfig")
            try data.write(to: file, options: .atomic)
            finish(.success(file))
        } catch { finish(.failure(error)) }
    }

    private func x12() -> NSError {
        NSError(domain: "VNBAPEX.Profile", code: 1, userInfo: nil)
    }

    private func finish(_ result: Result<URL, Error>) {
        guard !x13 else { return }
        x13 = true
        session?.finishTasksAndInvalidate()
        session = nil
        task = nil
        DispatchQueue.main.async { self.completion(result) }
    }
}
