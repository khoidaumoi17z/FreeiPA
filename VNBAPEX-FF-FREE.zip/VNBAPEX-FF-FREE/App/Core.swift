import UIKit
import WebKit
import AVFoundation

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = x0()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}

final class x0: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var x2: URL!
    private var x5 = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 7/255, green: 16/255, blue: 14/255, alpha: 1)
        guard let raw = X9.v0(),
              let url = URL(string: raw), url.scheme == "https", url.host != nil else {
            x10("Địa chỉ website trong app không hợp lệ.")
            return
        }
        x2 = url
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        let x15 = """
        (() => {
          const update = () => {
            document.querySelectorAll('.device-note').forEach(e => {
              if (e.textContent !== 'iPHONE / iPAD') e.textContent = 'iPHONE / iPAD';
            });
            document.querySelectorAll('.features, .hero > .description, footer > p').forEach(e => e.remove());
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while ((node = walker.nextNode())) {
              if (node.parentElement && !node.parentElement.closest('script, style')) {
                const next = node.nodeValue.replace(/tải hồ sơ VNBAPEX/gi, 'Tải VNBAPEX');
                if (next !== node.nodeValue) node.nodeValue = next;
              }
            }
          };
          update();
          new MutationObserver(update).observe(document.documentElement, {subtree: true, childList: true, characterData: true});
        })();
        """
        configuration.userContentController.addUserScript(WKUserScript(source: x15, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.allowsBackForwardNavigationGestures = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        webView.load(URLRequest(url: url, cachePolicy: .reloadRevalidatingCacheData))
    }

    private func x6(_ url: URL) {
        guard url.scheme == "https" || url.scheme == "http" else { return }
        UIApplication.shared.open(url, options: [:]) { [weak self] success in
            if !success { self?.x10("Không mở được liên kết. Hãy thử bằng Safari.") }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.pathExtension.lowercased() == "mobileconfig" {
            decisionHandler(.cancel)
            x6(url)
            return
        }
        if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
            return
        }
        guard url.scheme == "https" else {
            decisionHandler(.cancel)
            return
        }
        if navigationAction.targetFrame == nil && url.host == x2.host {
            decisionHandler(.cancel)
            webView.load(navigationAction.request)
        } else if url.host != x2.host {
            decisionHandler(.cancel)
            x6(url)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            if url.pathExtension.lowercased() == "mobileconfig" {
                x6(url)
            } else if url.scheme == "https", url.host == x2.host {
                webView.load(navigationAction.request)
            } else {
                x6(url)
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled {
            x10("Không tải được website. Kiểm tra kết nối mạng hoặc website GitHub Pages.")
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { x10("Tải trang bị gián đoạn. Vui lòng thử lại.") }
    }

    private func x10(_ message: String) {
        guard !x5 else { return }
        x5 = true
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let alert = UIAlertController(title: "VNBAPEX FF FREE", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Thử lại", style: .default) { [weak self] _ in
                self?.x5 = false
                if let url = self?.x2 { self?.webView?.load(URLRequest(url: url)) }
            })
            alert.addAction(UIAlertAction(title: "Đóng", style: .cancel) { [weak self] _ in self?.x5 = false })
            self.present(alert, animated: true)
        }
    }
}
